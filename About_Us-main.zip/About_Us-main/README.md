This is an about us section where the history, vision and goals of the organization are discussed.
